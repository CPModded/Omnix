# OMNIX — Final validation de travail

## Commandes
- 99 fichiers de commandes TypeScript détectés, y compris le sous-dossier moderation.
- 99/99 disposent d'un SlashCommandBuilder.
- 99/99 disposent d'un execute().
- 99/99 disposent d'une description.
- `/help` s'appuie sur le registre réel des commandes chargées.
- Le loader conserve maintenant le fichier et la catégorie d'origine de chaque commande.
- Les métriques d'exécution sont conservées en mémoire par commande.
- `/health` expose les commandes chargées, découvertes, erreurs d'exécution et fichiers manquants.
- `npm run audit:commands` et `npm run audit:commands:quality` sont prévus pour l'environnement où les dépendances sont installées.

## Interactions / tickets
- Création de ticket : un seul message de progression, mis à jour au fil des étapes.
- Les doublons d'interaction restent protégés localement et via MongoDB.
- Les permissions staff sont contrôlées par catégorie de ticket.

## Localisation
- Langues configurées : fr, en, de, es, it, pt-BR, pt-PT, tr, ar, so.
- Priorité Discord : préférence utilisateur > rôle de langue > locale Discord > locale détectée > locale serveur.
- Le site peut détecter le pays depuis l'IP et la langue depuis Accept-Language.
- Détection VPN/proxy/Tor facultative via IPQUALITYSCORE_API_KEY.
- Discord ne fournit pas l'IP d'un membre au bot : la géolocalisation IP reste donc web-only.
- `/language` est réservé aux OWNER_IDS.

## Limites de validation
- Le dépôt de travail ne contient pas node_modules.
- La compilation TypeScript complète et les tests Jest nécessitent l'installation des dépendances et les variables d'environnement réelles.
- Aucun test Discord/MongoDB/Render n'est déclaré réussi sans exécution réelle.
