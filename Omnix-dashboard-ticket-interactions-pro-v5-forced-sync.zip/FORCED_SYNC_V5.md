# Omnix V5 — Forced Sync

- Dashboard configuration: MongoDB read-after-write verification.
- Premium server: `/api/licenses/activate-server`, maximum 10 servers for an eligible Premium account/license.
- Admin server Premium: dedicated area plus corrected POST route.
- Home: visible diagnostic terminal removed; replaced by product feature cards.

TypeScript full build was not claimed here because this working archive does not contain node_modules.
