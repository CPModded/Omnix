# OMNIX — Audit de synchronisation Web / API / Bot

## Corrigé dans cette version

- `/servers`, `/activity`, `/statistics` ont maintenant une route Web authentifiée.
- `/profile`, `/servers`, `/activity`, `/statistics` utilisent la même vue `account.ejs` avec un paramètre `page` explicite.
- Les API `/api/me/overview`, `/api/me/activity` et `/api/me/statistics` appelées par `account.ejs` existent maintenant.
- La lecture d'une configuration de serveur passe par `getGuildConfig()`, donc le Web et le bot utilisent les mêmes defaults/réparations MongoDB.
- La sauvegarde de configuration effectue une relecture MongoDB après écriture et vérifie les états `modules.*.enabled` demandés.
- Les montages CSS recherchent les dossiers `public/css` possibles selon le mode de démarrage Render.

## Vérification statique

La compilation complète ne peut pas être déclarée ici sans les dépendances du projet (`node_modules` n'est pas inclus dans cette base). Une vérification TypeScript locale est donc limitée aux erreurs de syntaxe et aux fichiers accessibles.

## À tester sur Render

1. Ouvrir `/profile`, `/servers`, `/activity`, `/statistics`.
2. Ouvrir un serveur dans le dashboard.
3. Activer un module non-Premium, enregistrer, quitter, revenir et vérifier qu'il reste actif.
4. Vérifier les logs `[Config API] ✓ Configuration MongoDB vérifiée` après chaque sauvegarde.
5. Si un paramètre ne persiste pas, les logs `CONFIG_PERSISTENCE_MISMATCH` donnent le champ concerné.
