/**
 * ====================================================================
 * CONTRÔLEUR D'ADMINISTRATION GLOBALE (OMNIX STAFF CORE - STABLE)
 * ====================================================================
 */

import type { Response } from 'express';
import { AuthenticatedRequest } from '../middlewares/auth.ts';
import { GuildConfig } from '../../models/GuildConfig.ts';
import { SystemMonitor } from '../../utils/systemMonitor.ts';
import { client as botClient } from '../../bot/client.ts';
import { User } from '../../models/User.ts';
import { ... } from '../../config/index.ts';

export class AdminController {
  // 1. Récupération des données d'analyse de performance (Monitoring)
  static async getMonitoring(req: AuthenticatedRequest, res: Response) {
    try {
      const stats = await SystemMonitor.getStats();
      return res.json(stats);
    } catch (error: any) {
      return res.status(500).json({ error: 'Échec de la collecte des métriques.' });
    }
  }

  // 2. Gestion de l'octroi de la licence Premium (Serveur OU Utilisateur Personnel)
  static async togglePremium(req: AuthenticatedRequest, res: Response) {
    const { guildId, isPremium, tier, durationInDays } = req.body;

    try {
      // SCÉNARIO A : Attribution d'une licence personnelle au membre (Bypass de serveur)
      if (guildId === 'USER_LICENSE') {
        const userId = req.body.userId || req.user?.discordId;
        if (!userId) {
          return res.status(400).json({ error: 'ID utilisateur Discord manquant.' });
        }

        const user = await User.findOne({ discordId: userId });
        if (!user) {
          return res.status(404).json({ error: 'Utilisateur introuvable.' });
        }

        // CORRECTIF DE SÉCURITÉ MONGOOSE : On vide le tableau via la méthode officielle .set()
        user.set('licenses', []);
        
        if (isPremium) {
          const now = new Date();
          const expiresAt = new Date();
          expiresAt.setDate(now.getDate() + durationInDays);

          // Génération d'une clé d'utilisateur unique
          const rand = Math.random().toString(36).substring(2, 8).toUpperCase();

          user.licenses.push({
            licenseKey: `OMNIX-USER-${rand}`,
            tier: durationInDays === 0 ? 'lifetime' : 'premium',
            status: 'active',
            activatedGuildId: null, // Licence d'utilisateur
            expiresAt: expiresAt
          });
        }

        await user.save();
        console.log(`[Admin API] ✅ Licence utilisateur mise à jour pour ${user.username} (Premium: ${isPremium})`);
        return res.json({ message: 'Licence utilisateur mise à jour.', user });
      }

      // SCÉNARIO B : Attribution d'une licence classique liée à un serveur (Guild ID)
      let config = await GuildConfig.findOne({ guildId });
      if (!config) {
        config = new GuildConfig({ guildId });
      }

      let expiresAt: Date | null = null;
      if (isPremium && durationInDays > 0) {
        expiresAt = new Date();
        expiresAt.setDate(expiresAt.getDate() + durationInDays);
      }

      config.premium.isPremium = isPremium;
      config.premium.tier = isPremium ? (durationInDays === 0 ? 'lifetime' : 'premium') : 'free';
      config.premium.expiresAt = expiresAt;

      await config.save();
      return res.json({ message: `Statut premium du serveur ${guildId} mis à jour.`, config });
    } catch (error: any) {
      console.error('[Admin API] ❌ Erreur togglePremium :', error.message);
      return res.status(500).json({ error: 'Impossible de modifier le statut.', details: error.message });
    }
  }

  // 3. Émission d'une annonce globale par le bot
  static async sendGlobalAnnouncement(req: AuthenticatedRequest, res: Response) {
    const { messageContent } = req.body;

    if (!messageContent) {
      return res.status(400).json({ error: 'Le contenu du message est requis.' });
    }

    try {
      let successfulSends = 0;

      for (const [guildId, guild] of botClient.guilds.cache) {
        const targetChannel = guild.systemChannel || guild.channels.cache.find(
          ch => ch.isTextBased() && ch.permissionsFor(guild.members.me!).has('SendMessages')
        );

        if (targetChannel && 'send' in targetChannel) {
          await targetChannel.send({ content: `📢 **Annonce Globale OMNIX**\n\n${messageContent}` }).catch(() => null);
          successfulSends++;
        }
      }

      return res.json({ message: `Annonce envoyée avec succès sur ${successfulSends} serveur(s).` });
    } catch (error: any) {
      return res.status(500).json({ error: 'Échec de l\'envoi de l\'annonce globale.' });
    }
  }

  // 4. Récupération de tous les utilisateurs inscrits en base (Réservé Staff)
  static async getUsers(req: AuthenticatedRequest, res: Response) {
    try {
      const users = await User.find({}).sort({ createdAt: -1 });
      return res.json(users);
    } catch (error: any) {
      console.error('[Admin API] ❌ Échec de récupération des utilisateurs :', error.message);
      return res.status(500).json({ error: 'Impossible de récupérer la liste.' });
    }
  }

  // 5. Blacklister ou débannir un utilisateur de la plateforme
  static async toggleBlacklist(req: AuthenticatedRequest, res: Response) {
    const { userId, isBlacklisted } = req.body;

    try {
      const user = await User.findOne({ discordId: userId });
      if (!user) {
        return res.status(404).json({ error: 'Utilisateur introuvable.' });
      }

      if (user.isAdmin && isBlacklisted) {
        return res.status(400).json({ error: 'Impossible de bannir un membre du staff.' });
      }

      user.isBlacklisted = isBlacklisted;
      await user.save();

      console.log(`[Admin API] 🛑 Statut Blacklist de ${user.username} modifié : ${isBlacklisted}`);
      return res.json({ message: 'Statut de bannissement mis à jour avec succès.', user });
    } catch (error: any) {
      console.error('[Admin API] ❌ Erreur toggleBlacklist :', error.message);
      return res.status(500).json({ error: 'Échec de la modification du bannissement.', details: error.message });
    }
  }
}